//
//  ViewController.swift
//  AEPTargetExample
//
//  Created by Vijay on 10/06/21.
//

import UIKit

class AdobeFramework {

    func initialSetup() {
        MobileCore.setLogLevel(.debug)
        MobileCore.registerExtensions([Target.self, AEPMobileServices.self, AEPAssurance.self], {
            MobileCore.configureWith(appId: "APP-ID")
        })
        
        MobileCore.lifecycleStart(additionalContextData: nil)

    }
    
    func targetLoad() {
        targetLoad(withName: "name", defaultContent: "content", parameters: ["id":"1234"]) { (content) in
            print(content)
            
            
//            returns error -
//                expression produced error: error: virtual filesystem overlay file '/Users/abcd/Library/Developer/Xcode/DerivedData/AEPCore-hitruxktrhfcygasuurgsqerciki/Build/Intermediates.noindex/ArchiveIntermediates/AEP-All/IntermediateBuildFilesPath/AEPCore.build/Release-iphonesimulator/AEPCore.build/all-product-headers.yaml' not found
//
//            error: couldn't IRGen expression. Please check the above error messages for possible root causes.
        }
    }
    
    func targetLoad(withName: String, defaultContent: String, parameters: [String: String], callback: @escaping (String?) -> Void) {
        let targetParams = TargetParameters.init(parameters: parameters, profileParameters: nil, order: nil, product: nil)
        let targetRequest = TargetRequest.init(mboxName: withName, defaultContent: defaultContent, targetParameters: targetParams) { (result) in
            callback(result)
        }
        Target.retrieveLocationContent([targetRequest])
    }
}

